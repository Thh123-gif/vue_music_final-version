import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Recommend',
    component:()=>import('../views/Recommend'),
    meta:{showNav:true}  //meta路由原信息.
  }, 
  {
    path:'/playlist/:plistid',
    name:'Playlist',
    component:()=>import('../views/Playlist'),
    props:true,
    meta:{showNav:false}  //meta路由原信息.
  },
  {
    path:'/hot',
    name:'Hot',
    component:()=>import('../views/HotMusic'),
    meta:{showNav:true}  //meta路由原信息.
  },
  {
    path:'/search',
    name:'Search',
    component:()=>import('../views/Search'),
    meta:{showNav:true}  //meta路由原信息.
  }
]

const router = new VueRouter({
  routes
})

export default router
